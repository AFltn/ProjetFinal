package sopraAjc.projetFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetFinalApplication.class, args);
	}

}
